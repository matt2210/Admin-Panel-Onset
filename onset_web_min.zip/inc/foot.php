
<footer class="main-footer">
  <div class="float-right d-none d-sm-block">
    <b>V. Alpha</b> 1.0</div>
  <strong>Copyright &copy; 2014-2019 BlackWido</a>.</strong> All rights
  reserved. Template Made By <a href="http://adminlte.io">AdminLTE.io</a>
</footer>
